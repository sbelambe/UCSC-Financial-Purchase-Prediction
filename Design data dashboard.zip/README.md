
  # Design data dashboard

  This is a code bundle for Design data dashboard. The original project is available at https://www.figma.com/design/tnYyN39Y64D3vjtNQ7cMBD/Design-data-dashboard.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  